package com.example.appdepizzaria1.model

data class Product(
    val imgProduct: Int,
    val name: String,
    val price: String
)
